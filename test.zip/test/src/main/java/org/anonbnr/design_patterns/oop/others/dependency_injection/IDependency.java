package org.anonbnr.design_patterns.oop.others.dependency_injection;

public interface IDependency {
	/* METHODS */
	String getCustomerName(int id);
}
