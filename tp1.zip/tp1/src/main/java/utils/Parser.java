package utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.eclipse.core.internal.utils.FileUtil;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

public class Parser {
	
	private String projectPath; //= "C:\\Users\\zakarea.alshara\\osgi_workspace\\projectToParse";
	private String projectSourcePath; //= projectPath + "\\src";
	private String jrePath; //= "C:\\Program Files\\Java\\jre1.8.0_51\\lib\\rt.jar";
	
	public Parser() {
		this.projectPath = "/home/e20190001127/Documents/M2/S9/HAI913I-Restructuration/TP1_Partie2";
		this.projectSourcePath = this.projectPath + "/src";
		this.jrePath = "";
	}
	
	public Parser(String projectPath) {
		this.projectPath = projectPath;
		this.projectSourcePath = projectPath + "/src";
		this.jrePath = "";
	}
	
	public String getProjectPath() {
		return this.projectPath;
	}
	
	public void setProjectPath(String projectPath) {
		this.projectPath = projectPath;
	}
	
	public String getProjectSourcePath() {
		return this.projectSourcePath;
	}
	
	public void setProjectSourcePath(String projectSourcePath) {
		this.projectSourcePath = projectSourcePath;
	}
	
	public String getJrePath() {
		return this.jrePath;
	}
	
	public void setJrePath(String jrePath) {
		this.jrePath = jrePath;
	}

	// Read all java files from specific folder
	public ArrayList<File> listJavaFilesForFolder(final File folder) {
		ArrayList<File> javaFiles = new ArrayList<File>();
		for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				javaFiles.addAll(listJavaFilesForFolder(fileEntry));
			} else if (fileEntry.getName().contains(".java")) {
				// System.out.println(fileEntry.getName());
				javaFiles.add(fileEntry);
			}
		}

		return javaFiles;
	}

	// Create AST
	public CompilationUnit parse(char[] classSource) {
		ASTParser parser = ASTParser.newParser(AST.JLS4); // java +1.6
		parser.setResolveBindings(true);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
 
		parser.setBindingsRecovery(true);
 
		Map options = JavaCore.getOptions();
		parser.setCompilerOptions(options);
 
		parser.setUnitName("");
 
		String[] sources = { this.projectSourcePath }; 
		String[] classpath = {this.jrePath};
 
		parser.setEnvironment(classpath, sources, new String[] { "UTF-8"}, true);
		parser.setSource(classSource);
		
		return (CompilationUnit) parser.createAST(null); // create and parse
	}
}
