package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import utils.CallGraph;
import utils.ClassVisitor;
import utils.MethodDeclarationVisitor;
import utils.MethodInvocationVisitor;
import utils.PackageVisitor;
import utils.Parser;

import org.apache.commons.io.FileUtils;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.TypeDeclaration;

public class Main {
	
	// C:\Users\maxb\Documents\Cours\M2\S9\HAI913I-Restructuration\test
	// /home/e20190001127/Documents/M2/S9/HAI913I-Restructuration/test
	
	private static int totalLines = 0;
	private static PackageVisitor packageVisitor = new PackageVisitor();
	private static ClassVisitor classVisitor = new ClassVisitor();
	private static MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
	private static CallGraph callGraph = new CallGraph();

	public static void main(String[] args) throws IOException {
		
		System.out.println("Chemin absolu vers le projet à analyser :");
		Scanner scan = new Scanner(System.in);
		String input = scan.next();
	
		Parser p = new Parser(input);

		// Read java files
		final File folder = new File(p.getProjectSourcePath());
		ArrayList<File> javaFiles = p.listJavaFilesForFolder(folder);
		
		for (File fileEntry : javaFiles) {
			String content = FileUtils.readFileToString(fileEntry, StandardCharsets.UTF_8);
			CompilationUnit parsed = p.parse(content.toCharArray());
			
			countLines(fileEntry);
			
			parsed.accept(packageVisitor);
			parsed.accept(classVisitor);
			parsed.accept(methodDeclarationVisitor);
		}
		
		for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
			MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
			methodDeclaration.accept(methodInvocationVisitor);
			for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
				callGraph.addMethodValue(methodDeclarationToString(methodDeclaration), methodInvocationToString(methodInvocation));
			}
		}
		
		// Return results
		System.out.println("\n=== ANALYSE DU PROJET ===\n");
		System.out.println("- Nombre de classes de l’application.");
		System.out.println(classVisitor.getClasses().size());
		System.out.println("- Nombre de lignes de code de l’application.");
		System.out.println(totalLines);
		System.out.println("- Nombre total de méthodes de l’application.");
		System.out.println(methodDeclarationVisitor.getMethods().size());
		System.out.println("- Nombre total de packages de l’application.");
		System.out.println(packageVisitor.getPackages().size());
		System.out.println("- Nombre moyen de méthodes par classe.");
		System.out.println((float) classVisitor.getNMethods() / (float) classVisitor.getClasses().size());
		System.out.println("- Nombre moyen de lignes de code par méthode.");
		System.out.println((float) methodDeclarationVisitor.getNLines() / (float) methodDeclarationVisitor.getMethods().size());
		System.out.println("- Nombre moyen d’attributs par classe.");
		System.out.println((float) classVisitor.getNAttributes() / (float) classVisitor.getClasses().size());
		System.out.println("- Les 10% des classes qui possèdent le plus grand nombre de méthodes.");
		System.out.println(tenPercentMethods());
		System.out.println("- Les 10% des classes qui possèdent le plus grand nombre d’attributs.");
		System.out.println(tenPercentAttributes());
		System.out.println("- Les classes qui font partie en même temps des deux catégories précédentes.");
		System.out.println(bothTenPercent());
		System.out.println("- Les classes qui possèdent plus de X méthodes (ici X vaut moyenne + 1).");
		System.out.println(aboveAverage());
		System.out.println("- Les 10% des méthodes qui possèdent le plus grand nombre de lignes de code.");
		System.out.println(tenPercentLines());
		System.out.println("- Le nombre maximal de paramètres par rapport à toutes les méthodes de l’application.");
		System.out.println(maxParams());
		System.out.println();
		
		System.out.println("\n=== GRAPHE D'APPEL ===\n");
		System.out.println(callGraph.toString());
	}
	
	public static void countLines(File file) {
	    int lines = 0;

	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        while (reader.readLine() != null)
	            lines++;
	    } catch (IOException e) { e.printStackTrace(); }

	    totalLines += lines;
	}
	
	public static String tenPercentMethods() {
		Map<String, Integer> classMethodCounts = new HashMap<>();
		
		for (TypeDeclaration classNode : classVisitor.getClasses()) {
	        String className = classNode.getName().getIdentifier();
	        int methodCount = classNode.getMethods().length;
	        classMethodCounts.put(className, methodCount);
	    }
		
		List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(classMethodCounts.entrySet());
		sortedEntries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));
		List<String> top10 = sortedEntries.subList(0, (int) Math.ceil(sortedEntries.size() * 0.1))
		        .stream()
		        .map(Map.Entry::getKey)
		        .collect(Collectors.toList());
		
		return String.join(", ", top10);
	}
	
	public static String tenPercentAttributes() {
	    Map<String, Integer> classAttributeCounts = new HashMap<>();
	    
	    for (TypeDeclaration classNode : classVisitor.getClasses()) {
	        String className = classNode.getName().getIdentifier();
	        int attributeCount = classNode.getFields().length;
	        classAttributeCounts.put(className, attributeCount);
	    }
	    
	    List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(classAttributeCounts.entrySet());
	    sortedEntries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));
	    List<String> top10 = sortedEntries.subList(0, (int) Math.ceil(sortedEntries.size() * 0.1))
	            .stream()
	            .map(Map.Entry::getKey)
	            .collect(Collectors.toList());
	    
	    return String.join(", ", top10);
	}
	
	public static String bothTenPercent() {
	    String[] methodsArray = tenPercentMethods().split(", ");
	    String[] attributesArray = tenPercentAttributes().split(", ");
	    
	    Set<String> methodsSet = new HashSet<>(Arrays.asList(methodsArray));
	    Set<String> attributesSet = new HashSet<>(Arrays.asList(attributesArray));

	    Set<String> commonClasses = new HashSet<>(methodsSet);
	    commonClasses.retainAll(attributesSet);

	    return String.join(", ", commonClasses);
	}
	
	public static String aboveAverage() {
		Map<String, Integer> classMethodCounts = new HashMap<>();
		
		for (TypeDeclaration classNode : classVisitor.getClasses()) {
	        String className = classNode.getName().getIdentifier();
	        int methodCount = classNode.getMethods().length;
	        classMethodCounts.put(className, methodCount);
	    }
		
		List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(classMethodCounts.entrySet());
		sortedEntries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));
		
		float averageMethods = (float) (classVisitor.getNMethods() / classVisitor.getClasses().size());
		
		int i;
		for (i = 0; i < sortedEntries.size(); i++) {
			if ((float) sortedEntries.get(i).getValue() <= averageMethods) {
				break;
			}
		}
		
		List<String> aboveAverage = sortedEntries.subList(0, i)
	            .stream()
	            .map(Map.Entry::getKey)
	            .collect(Collectors.toList());
	    
	    return String.join(", ", aboveAverage);
	}
	
	public static String tenPercentLines() {
		Map<String, Integer> methodLinesCounts = new HashMap<>();
		
		for (MethodDeclaration methodNode : methodDeclarationVisitor.getMethods()) {
	        String methodName = methodNode.getName().getIdentifier();
	        int lineCount = 0;
	        if (methodNode.getBody() != null) {
	        	lineCount = methodNode.getBody().toString().split("\n").length;
	        }
	        methodLinesCounts.put(methodNode.resolveBinding().getDeclaringClass().getName() + '.' + methodName, lineCount);
	    }
		
		List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(methodLinesCounts.entrySet());
		sortedEntries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));
		List<String> top10 = sortedEntries.subList(0, (int) Math.ceil(sortedEntries.size() * 0.1))
		        .stream()
		        .map(Map.Entry::getKey)
		        .collect(Collectors.toList());
		
		return String.join(", ", top10);
	}
	
	public static String maxParams() {
		String methodName = "";
		int methodParamsCount = 0;
		
		for (MethodDeclaration methodNode : methodDeclarationVisitor.getMethods()) {
			if (methodName == "") {
				methodName = methodNode.resolveBinding().getDeclaringClass().getName() + '.' + methodNode.getName().getIdentifier();
				methodParamsCount = methodNode.parameters().size();
			}
			if (methodNode.parameters().size() > methodParamsCount) {
				methodName = methodNode.resolveBinding().getDeclaringClass().getName() + '.' + methodNode.getName().getIdentifier();
				methodParamsCount = methodNode.parameters().size();
			}
	    }
		
		return methodName + " (" + methodParamsCount + ")";
	}
	
	public static String methodDeclarationToString(MethodDeclaration methodDeclaration) {
		return methodDeclaration.resolveBinding().getDeclaringClass().getName() + '.' + methodDeclaration.getName().getIdentifier();
	}
	
	public static String methodInvocationToString(MethodInvocation methodInvocation) {
	
	    Expression expression = methodInvocation.getExpression();
	    String className = "";
	
	    if (expression != null) {
	        if (expression.getNodeType() == ASTNode.SIMPLE_NAME) {
	            className = ((SimpleName) expression).getIdentifier();
	        } else if (expression.getNodeType() == ASTNode.QUALIFIED_NAME) {
	            className = ((QualifiedName) expression).getQualifier().toString();
	        }
	    } else {
	    	className = "classNotFound";	
	    }
	    return className + "." + methodInvocation.getName().getIdentifier();
    }
}
