package utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CallGraph {
	private Map<String, List<String>> callGraph = new HashMap<>();
	
	public CallGraph() {
		this.callGraph = new HashMap<>();
	}
	
	public CallGraph(Map<String, List<String>> callGraph) {
		this.callGraph = callGraph;
	}
	
	public Map<String, List<String>> getCallGraph() {
		return this.callGraph;
	}
	
	public void setCallGraph(Map<String, List<String>> callGraph) {
		this.callGraph = callGraph;
	}
	
	public void addMethodKey(String method) {
        if (!callGraph.containsKey(method)) {
            callGraph.put(method, new ArrayList<>());
        }
	}
	
	public void addMethodValue(String key, String value) {
        List<String> methodArray = callGraph.get(key);
        if (methodArray == null) {
            this.addMethodKey(key);
            this.addMethodValue(key, value);
            methodArray = callGraph.get(key);
        }
        if (!callGraph.containsKey(value)) {
            this.addMethodKey(value);
        }
        methodArray.add(value);
    }
	
	public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, List<String>> entry : callGraph.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();
            sb.append("- ").append(key).append(" : ");
            
            if (!values.isEmpty()) {
                sb.append("[");
                for (int i = 0; i < values.size(); i++) {
                    sb.append(values.get(i));
                    if (i < values.size() - 1) {
                        sb.append(", ");
                    }
                }
                sb.append("]");
            } else {
                sb.append("[]");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}