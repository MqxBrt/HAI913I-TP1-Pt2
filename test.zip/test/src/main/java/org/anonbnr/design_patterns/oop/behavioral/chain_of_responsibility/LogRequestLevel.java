package org.anonbnr.design_patterns.oop.behavioral.chain_of_responsibility;

/**
 * a LogRequestLevel marker interface that is used as a parent
 * to all LogRequestLevel enumerations.
 * @author anonbnr
 *
 */
public interface LogRequestLevel {
	
	/**
	 * Gets the integer value of this LogRequestLevel.
	 * @return the integer value of this LogRequestLevel.
	 */
	int value();
}