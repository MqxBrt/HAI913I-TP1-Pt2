package utils;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.MethodDeclaration;

public class MethodDeclarationVisitor extends ASTVisitor {
	List<MethodDeclaration> methods = new ArrayList<MethodDeclaration>();
	int nLines = 0;
	
	public boolean visit(MethodDeclaration node) {
		methods.add(node);
		if (node.getBody() != null) {
			nLines += node.getBody().toString().split("\n").length;
		}
		return super.visit(node);
	}
	
	public List<MethodDeclaration> getMethods() {
		return methods;
	}
	
	public int getNLines() {
		return nLines;
	}
}
