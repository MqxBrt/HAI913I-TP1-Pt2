package org.anonbnr.design_patterns.oop.creational.abstract_factory.gui_factory;

// Abstract Product B
public interface CheckBox {
    void paint();
}
