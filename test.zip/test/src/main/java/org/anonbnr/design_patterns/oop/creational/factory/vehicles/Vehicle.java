package org.anonbnr.design_patterns.oop.creational.factory.vehicles;

// Product interface
public interface Vehicle{
    void startEngine();
}