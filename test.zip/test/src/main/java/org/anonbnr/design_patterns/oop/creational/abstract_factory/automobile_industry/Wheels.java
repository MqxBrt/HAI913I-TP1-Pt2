package org.anonbnr.design_patterns.oop.creational.abstract_factory.automobile_industry;

// Abstract Product B
public interface Wheels {
    void roll();
}
