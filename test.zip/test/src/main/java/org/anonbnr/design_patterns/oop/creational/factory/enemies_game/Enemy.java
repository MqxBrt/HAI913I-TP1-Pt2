package org.anonbnr.design_patterns.oop.creational.factory.enemies_game;

// Product interface
public interface Enemy{
    void attack();
    void move();
}