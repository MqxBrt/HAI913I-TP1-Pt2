package org.anonbnr.design_patterns.oop.creational.abstract_factory.gui_factory;

// Abstract Product A
public interface Button{
    void paint();
}